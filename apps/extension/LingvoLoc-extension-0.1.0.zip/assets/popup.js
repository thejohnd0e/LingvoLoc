(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))l(e);new MutationObserver(e=>{for(const a of e)if(a.type==="childList")for(const p of a.addedNodes)p.tagName==="LINK"&&p.rel==="modulepreload"&&l(p)}).observe(document,{childList:!0,subtree:!0});function c(e){const a={};return e.integrity&&(a.integrity=e.integrity),e.referrerPolicy&&(a.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?a.credentials="include":e.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function l(e){if(e.ep)return;e.ep=!0;const a=c(e);fetch(e.href,a)}})();const y="http://127.0.0.1:47831/api/v1";async function b(t,o,c,l){const e=await fetch(`${y}/translate`,{method:"POST",headers:{Authorization:`Bearer ${t}`,"Content-Type":"application/json"},body:JSON.stringify({text:o,sourceLanguage:c,targetLanguage:l})});if(!e.ok){const a=await e.json().catch(()=>({}));throw new Error(a.error??`LingvoLoc API returned HTTP ${e.status}`)}return await e.json()}async function w(t){const o=await fetch(`${y}/status`,{headers:{Authorization:`Bearer ${t}`}});if(!o.ok){const c=await o.json().catch(()=>({}));throw new Error(c.error??`LingvoLoc API returned HTTP ${o.status}`)}return await o.json()}async function L(){const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});return t.id?(await chrome.scripting.executeScript({target:{tabId:t.id},func:()=>window.getSelection()?.toString()??""}))[0]?.result?.trim()??"":""}const v=document.querySelector("#app");if(!v)throw new Error("Popup root is missing");const n={token:"",source:"auto",target:"ru",text:"",fontSize:16};v.innerHTML=`
  <section class="shell">
    <header>
      <div>
        <span class="eyebrow">LOCAL TRANSLATION</span>
        <h1>LingvoLoc</h1>
      </div>
      <div class="header-tools">
        <div class="font-controls" aria-label="Text size">
          <button id="font-decrease" class="font-button" type="button" aria-label="Decrease text size">−</button>
          <span id="font-size">16px</span>
          <button id="font-increase" class="font-button" type="button" aria-label="Increase text size">+</button>
        </div>
        <span class="status" id="status">READY</span>
      </div>
    </header>
    <div class="pairing">
      <label class="field"><span>Pairing token</span><input id="token" type="password" autocomplete="off" placeholder="Paste token from LingvoLoc" /></label>
      <button id="pair" class="secondary" type="button">Pair extension</button>
    </div>
    <div class="row">
      <label class="field compact"><span>From</span><select id="source"><option value="auto">Auto</option><option value="en">English</option><option value="ru">Russian</option><option value="de">German</option><option value="es">Spanish</option><option value="fr">French</option></select></label>
      <label class="field compact"><span>To</span><select id="target"><option value="ru">Russian</option><option value="en">English</option><option value="de">German</option><option value="es">Spanish</option><option value="fr">French</option></select></label>
    </div>
    <label class="field"><span>Selected text</span><textarea id="text" rows="5" placeholder="Select text on a page, or paste it here"></textarea></label>
    <button id="translate" type="button">Translate locally</button>
    <output id="result" aria-live="polite"></output>
    <p class="hint">The extension sends text only to LingvoLoc on this computer.</p>
  </section>
`;const u=document.querySelector("#token"),h=document.querySelector("#source"),g=document.querySelector("#target"),d=document.querySelector("#text"),f=document.querySelector("#translate"),m=document.querySelector("#pair"),E=document.querySelector("#font-decrease"),z=document.querySelector("#font-increase"),k=document.querySelector("#font-size"),s=document.querySelector("#status"),r=document.querySelector("#result"),i=await chrome.storage.local.get(["apiToken","pendingSelection","fontSize"]);n.token=typeof i.apiToken=="string"?i.apiToken:"";n.fontSize=typeof i.fontSize=="number"?Math.min(24,Math.max(12,i.fontSize)):16;n.text=typeof i.pendingSelection=="string"?i.pendingSelection:await L().catch(()=>"");typeof i.pendingSelection=="string"&&i.pendingSelection.trim()&&await chrome.storage.local.remove("pendingSelection");u.value=n.token;d.value=n.text;function S(){const t=`${n.fontSize}px`;k.textContent=t,d.style.fontSize=t,r.style.fontSize=t}function x(t){n.fontSize=Math.min(24,Math.max(12,n.fontSize+t)),chrome.storage.local.set({fontSize:n.fontSize}),S()}E.addEventListener("click",()=>x(-1));z.addEventListener("click",()=>x(1));S();u.addEventListener("input",()=>{n.token=u.value.trim()});h.addEventListener("change",()=>{n.source=h.value});g.addEventListener("change",()=>{n.target=g.value});d.addEventListener("input",()=>{n.text=d.value});m.addEventListener("click",async()=>{const t=u.value.trim();if(!t){s.textContent="ERROR",r.textContent="Paste the pairing token first.";return}m.disabled=!0,s.textContent="CHECKING",r.textContent="";try{const o=await w(t);await chrome.storage.local.set({apiToken:t}),n.token=t,s.textContent="PAIRED",r.textContent=o.detail}catch(o){s.textContent="ERROR",r.textContent=o instanceof Error?o.message:"Pairing failed"}finally{m.disabled=!1}});f.addEventListener("click",async()=>{if(!n.token||!n.text.trim()){r.textContent="Add a pairing token and text first.";return}f.disabled=!0,s.textContent="WORKING",r.textContent="";try{const t=await b(n.token,n.text.trim(),n.source,n.target);r.textContent=t.text,s.textContent=`${t.latency_ms} MS`}catch(t){r.textContent=t instanceof Error?t.message:"Translation failed",s.textContent="ERROR"}finally{f.disabled=!1}});
