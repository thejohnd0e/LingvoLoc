const a=new Set(["ADDRESS","ARTICLE","ASIDE","BLOCKQUOTE","DIV","FIGCAPTION","H1","H2","H3","H4","H5","H6","HEADER","LI","P","PRE","SECTION","TR"]);function i(){const o=window.getSelection();if(!o?.rangeCount)return"";const c=o.getRangeAt(0).cloneContents(),t=e=>{if(e.nodeType===Node.TEXT_NODE)return e.textContent??"";if(e.nodeType===Node.DOCUMENT_FRAGMENT_NODE)return Array.from(e.childNodes,t).join("");if(e.nodeType!==Node.ELEMENT_NODE)return"";const n=e;if(n.tagName==="BR")return`
`;const r=Array.from(n.childNodes,t).join("");return a.has(n.tagName)?`

${r}

`:r};return t(c).replace(/[ \t]*\n[ \t]*/g,`
`).replace(/\n{3,}/g,`

`).trim()}document.addEventListener("selectionchange",()=>{chrome.storage.local.set({latestSelection:{pageUrl:location.href,text:i()}})});
